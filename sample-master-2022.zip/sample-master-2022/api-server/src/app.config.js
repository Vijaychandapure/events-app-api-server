/**
 * Place to store data specific to this instance
 * DO NOT store secrets here
 * DO NOT store state here - must be part of a stateless service
 */
class AppConfig {
    version = '1.0.1';
    team = 'Your Team Name';
}
module.exports = AppConfig;
