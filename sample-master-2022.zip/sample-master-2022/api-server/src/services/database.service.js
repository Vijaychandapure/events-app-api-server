const MockDatabaseService = require("./class.mock.database.service");

const db = new MockDatabaseService();
module.exports = db;
