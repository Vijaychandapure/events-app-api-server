class AppConfig {
    version = '1.0.1';
}
module.exports = AppConfig;
